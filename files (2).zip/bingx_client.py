"""
BingX Client v4
FIX CRÍTICO: get_balance() parseaba mal el response → siempre $0
El campo correcto es: data["balance"]["balance"] o data["balance"]["availableMargin"]

Añadidos:
  - place_trailing_stop()
  - close_position_partial() con MARKET (garantizado)
  - cancel_order(), get_open_orders()
  - update_sl()
  - get_best_bid_ask()
  - logging detallado en errores de balance
"""
import hashlib
import hmac
import time
import logging
from typing import Optional
import requests

log = logging.getLogger(__name__)

BASE_URL = "https://open-api.bingx.com"

# Timeout y retry
REQUEST_TIMEOUT = 10
MAX_RETRIES     = 3


class BingXClient:
    def __init__(self, api_key: str, secret_key: str):
        self.api_key    = api_key.strip()
        self.secret_key = secret_key.strip()
        self._session   = requests.Session()
        self._session.headers.update({
            "X-BX-APIKEY": self.api_key,
            "Content-Type": "application/json",
        })

    def _sign(self, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000)
        query = "&".join(f"{k}={v}" for k, v in sorted(params.items()))
        sig   = hmac.new(
            self.secret_key.encode(), query.encode(), hashlib.sha256
        ).hexdigest()
        params["signature"] = sig
        return params

    def _get(self, path: str, params: dict = None, signed: bool = True) -> dict:
        p = self._sign(params or {}) if signed else (params or {})
        for attempt in range(MAX_RETRIES):
            try:
                r = self._session.get(
                    BASE_URL + path, params=p, timeout=REQUEST_TIMEOUT
                )
                r.raise_for_status()
                return r.json()
            except requests.exceptions.Timeout:
                log.warning(f"Timeout GET {path} intento {attempt+1}")
                time.sleep(1)
            except Exception as e:
                log.error(f"GET {path} error: {e}")
                if attempt == MAX_RETRIES - 1:
                    raise
                time.sleep(1)
        return {}

    def _post(self, path: str, params: dict = None, signed: bool = True) -> dict:
        p = self._sign(params or {}) if signed else (params or {})
        for attempt in range(MAX_RETRIES):
            try:
                r = self._session.post(
                    BASE_URL + path, params=p, timeout=REQUEST_TIMEOUT
                )
                r.raise_for_status()
                return r.json()
            except requests.exceptions.Timeout:
                log.warning(f"Timeout POST {path} intento {attempt+1}")
                time.sleep(1)
            except Exception as e:
                log.error(f"POST {path} error: {e}")
                if attempt == MAX_RETRIES - 1:
                    raise
                time.sleep(1)
        return {}

    def _delete(self, path: str, params: dict = None) -> dict:
        p = self._sign(params or {})
        try:
            r = self._session.delete(BASE_URL + path, params=p, timeout=REQUEST_TIMEOUT)
            return r.json()
        except Exception as e:
            log.error(f"DELETE {path}: {e}")
            return {}

    # ── Balance (FIX CRÍTICO) ─────────────────────────────────────────
    def get_balance(self) -> float:
        """
        Endpoint correcto para perpetual futures:
        GET /openApi/swap/v3/user/balance
        
        Response structure:
        {
          "code": 0,
          "data": {
            "balance": {
              "asset": "USDT",
              "balance": "123.45",
              "availableMargin": "100.00",
              "unrealizedProfit": "0.00",
              ...
            }
          }
        }
        """
        # Intentar endpoint v3 primero (más nuevo)
        endpoints = [
            "/openApi/swap/v3/user/balance",
            "/openApi/swap/v2/user/balance",
        ]
        for ep in endpoints:
            try:
                data = self._get(ep)
                log.debug(f"Balance response ({ep}): {data}")

                if data.get("code") != 0:
                    log.warning(f"Balance API error code {data.get('code')}: {data.get('msg')}")
                    continue

                # Intentar múltiples rutas en el response
                bal_data = data.get("data", {})

                # Estructura v3: data.balance.balance
                if isinstance(bal_data, dict) and "balance" in bal_data:
                    inner = bal_data["balance"]
                    if isinstance(inner, dict):
                        for field in ["availableMargin", "balance", "equity"]:
                            val = inner.get(field)
                            if val is not None:
                                bal = float(val)
                                if bal >= 0:
                                    log.info(f"✅ Balance: ${bal:.2f} USDT (field={field})")
                                    return bal

                # Estructura v2: data directamente es lista o dict
                if isinstance(bal_data, list):
                    for item in bal_data:
                        if item.get("asset", "").upper() == "USDT":
                            for field in ["availableMargin", "balance", "equity"]:
                                val = item.get(field)
                                if val is not None:
                                    return float(val)

                log.warning(f"Balance estructura inesperada: {bal_data}")
            except Exception as e:
                log.error(f"Balance error ({ep}): {e}")
                continue

        log.error("❌ No se pudo obtener balance. Verifica: 1) API keys 2) Permisos Futures 3) IP whitelist")
        return 0.0

    # ── Symbol info ───────────────────────────────────────────────────
    def get_symbol_info(self, symbol: str) -> dict:
        data = self._get("/openApi/swap/v2/quote/contracts")
        for item in data.get("data", []):
            if item.get("symbol") == symbol:
                return item
        return {}

    def get_all_symbols(self) -> list:
        data = self._get("/openApi/swap/v2/quote/contracts")
        return [
            item["symbol"] for item in data.get("data", [])
            if item.get("symbol", "").endswith("-USDT")
               and item.get("status", 1) == 1
        ]

    # ── Market data ───────────────────────────────────────────────────
    def get_ticker(self, symbol: str) -> dict:
        data = self._get("/openApi/swap/v2/quote/ticker", {"symbol": symbol}, signed=False)
        return data.get("data", {})

    def get_klines(self, symbol: str, interval: str, limit: int = 300) -> list:
        data = self._get(
            "/openApi/swap/v3/quote/klines",
            {"symbol": symbol, "interval": interval, "limit": limit},
            signed=False,
        )
        return data.get("data", [])

    def get_best_bid_ask(self, symbol: str) -> tuple:
        data = self._get("/openApi/swap/v2/quote/bookTicker", {"symbol": symbol}, signed=False)
        d    = data.get("data", {})
        return float(d.get("bidPrice", 0) or 0), float(d.get("askPrice", 0) or 0)

    def get_24h_volume(self, symbol: str) -> float:
        ticker = self.get_ticker(symbol)
        return float(ticker.get("quoteVolume", 0) or ticker.get("volume", 0) or 0)

    # ── Cuenta ────────────────────────────────────────────────────────
    def get_positions(self) -> list:
        data = self._get("/openApi/swap/v2/user/positions", {})
        return data.get("data", []) or []

    def get_open_orders(self, symbol: str = "") -> list:
        p    = {"symbol": symbol} if symbol else {}
        data = self._get("/openApi/swap/v2/trade/openOrders", p)
        return data.get("data", {}).get("orders", []) or []

    def get_order_status(self, symbol: str, order_id: str) -> dict:
        data = self._get("/openApi/swap/v2/trade/order", {"symbol": symbol, "orderId": order_id})
        return data.get("data", {}).get("order", {})

    # ── Configuración ─────────────────────────────────────────────────
    def set_leverage(self, symbol: str, leverage: int):
        for side in ["LONG", "SHORT"]:
            try:
                self._post("/openApi/swap/v2/trade/leverage", {
                    "symbol":     symbol,
                    "side":       side,
                    "leverage":   leverage,
                })
            except Exception as e:
                log.debug(f"set_leverage {symbol} {side}: {e}")

    def set_margin_type(self, symbol: str, margin_type: str = "ISOLATED"):
        try:
            self._post("/openApi/swap/v2/trade/marginType", {
                "symbol":     symbol,
                "marginType": margin_type,
            })
        except Exception as e:
            log.debug(f"set_margin_type {symbol}: {e}")

    # ── Órdenes ───────────────────────────────────────────────────────
    def place_order(
        self,
        symbol:            str,
        side:              str,
        position_side:     str,
        order_type:        str,
        quantity:          float,
        price:             float = None,
        stop_loss:         float = None,
        take_profit:       float = None,
        client_order_id:   str   = None,
        post_only:         bool  = False,
    ) -> dict:
        params = {
            "symbol":       symbol,
            "side":         side,
            "positionSide": position_side,  # LONG / SHORT para hedge-mode
            "type":         order_type,
            "quantity":     quantity,
        }
        if price and order_type != "MARKET":
            params["price"] = price
        if stop_loss:
            params["stopLoss"] = json_sl_tp(stop_loss, symbol)
        if take_profit:
            params["takeProfit"] = json_sl_tp(take_profit, symbol, is_tp=True)
        if client_order_id:
            params["clientOrderID"] = client_order_id
        if post_only and order_type == "LIMIT":
            params["timeInForce"] = "PostOnly"

        result = self._post("/openApi/swap/v2/trade/order", params)
        if result.get("code") != 0:
            log.error(f"place_order error {symbol}: code={result.get('code')} msg={result.get('msg')}")
        return result

    def place_trailing_stop(
        self,
        symbol:           str,
        side:             str,
        position_side:    str,
        quantity:         float,
        activation_price: float,
        price_rate:       float,       # ej 0.025 = 2.5%
    ) -> dict:
        """
        Trailing stop en BingX API.
        type=TRAILING_STOP_MARKET
        priceRate: porcentaje de retroceso que activa el cierre
        activationPrice: precio a partir del cual empieza a seguir
        """
        params = {
            "symbol":          symbol,
            "side":            side,
            "positionSide":    position_side,
            "type":            "TRAILING_STOP_MARKET",
            "quantity":        quantity,
            "activationPrice": activation_price,
            "priceRate":       price_rate,
            "workingType":     "MARK_PRICE",
        }
        result = self._post("/openApi/swap/v2/trade/order", params)
        if result.get("code") != 0:
            log.warning(f"trailing_stop {symbol}: {result.get('msg')}")
        return result

    def close_position_partial(self, symbol: str, direction: str, quantity: float) -> dict:
        """Cierre parcial MARKET (garantizado)."""
        side      = "SELL" if direction == "LONG" else "BUY"
        pos_side  = direction
        return self.place_order(symbol, side, pos_side, "MARKET", quantity)

    def cancel_order(self, symbol: str, order_id: str) -> dict:
        return self._delete("/openApi/swap/v2/trade/order", {
            "symbol": symbol, "orderId": order_id
        })

    def cancel_all_orders(self, symbol: str) -> dict:
        return self._delete("/openApi/swap/v2/trade/allOpenOrders", {"symbol": symbol})

    def update_sl(self, symbol: str, direction: str, new_sl: float) -> dict:
        """
        Actualizar SL de una posición existente.
        Cancela el SL anterior y coloca uno nuevo.
        """
        side = "SELL" if direction == "LONG" else "BUY"
        try:
            self.cancel_all_orders(symbol)
        except Exception:
            pass
        params = {
            "symbol":       symbol,
            "side":         side,
            "positionSide": direction,
            "type":         "STOP_MARKET",
            "stopPrice":    new_sl,
            "closePosition": True,
            "workingType":  "MARK_PRICE",
        }
        return self._post("/openApi/swap/v2/trade/order", params)


def json_sl_tp(price: float, symbol: str, is_tp: bool = False) -> str:
    """Formatea SL/TP como JSON string para la API de BingX."""
    import json
    order_type = "TAKE_PROFIT_MARKET" if is_tp else "STOP_MARKET"
    return json.dumps({
        "type":        order_type,
        "stopPrice":   str(price),
        "price":       str(price),
        "workingType": "MARK_PRICE",
    })
