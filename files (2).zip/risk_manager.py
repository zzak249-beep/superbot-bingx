"""
Risk Manager v4
FIX vs v3:
  - MIN_NOTIONAL: $6 era demasiado bajo para algunos pares, ahora dinámico
  - balance < MIN_NOTIONAL*2 bloqueaba cuando balance era $0 por bug API
  - Añadido: warning más claro cuando el balance es sospechosamente bajo
  - can_open_trade: no bloquear por balance $0 si es DRY_RUN
"""
import os
import logging
from dataclasses import dataclass
from typing import Optional

log = logging.getLogger(__name__)

RISK_PER_TRADE    = 0.02    # 2% por trade (era 1% → más rentable)
MAX_POSITIONS     = 4
LEVERAGE          = 10
DAILY_LOSS_LIMIT  = 0.06    # 6%
MIN_NOTIONAL      = 5.5     # BingX mínimo real es ~$5
MAKER_FEE         = 0.0002
TAKER_FEE         = 0.0005

DRY_RUN = os.environ.get("DRY_RUN", "false").lower() == "true"


@dataclass
class TradeParams:
    symbol:       str
    direction:    str
    entry_price:  float
    sl_price:     float
    tp1_price:    float
    tp2_price:    float
    tp3_price:    float
    quantity:     float
    leverage:     int
    notional:     float
    risk_usdt:    float
    est_fee:      float


class RiskManager:
    def __init__(
        self,
        risk_pct:         float = RISK_PER_TRADE,
        max_pos:          int   = MAX_POSITIONS,
        leverage:         int   = LEVERAGE,
        daily_loss_limit: float = DAILY_LOSS_LIMIT,
    ):
        self.risk_pct         = risk_pct
        self.max_pos          = max_pos
        self.leverage         = leverage
        self.daily_loss_limit = daily_loss_limit

        self._daily_start_balance: Optional[float] = None
        self._daily_pnl:    float = 0.0
        self._daily_trades: int   = 0
        self._weekly_pnl:   float = 0.0
        self._total_fees:   float = 0.0

    def reset_daily(self, balance: float):
        self._daily_start_balance = balance
        self._daily_pnl    = 0.0
        self._daily_trades = 0
        log.info(f"📅 Daily reset | Balance: ${balance:.2f} | Risk/trade: {self.risk_pct*100:.1f}% | Lev: {self.leverage}x")

    def record_pnl(self, pnl_usdt: float, fee: float = 0.0):
        self._daily_pnl    += pnl_usdt
        self._weekly_pnl   += pnl_usdt
        self._total_fees   += fee
        self._daily_trades += 1
        log.info(f"📊 P&L: {pnl_usdt:+.2f} | Daily: {self._daily_pnl:+.2f} | Fee: -{fee:.3f}")

    def is_kill_switch(self, balance: float) -> bool:
        if self._daily_start_balance is None or self._daily_start_balance <= 0:
            return False
        loss_pct = -self._daily_pnl / self._daily_start_balance if self._daily_pnl < 0 else 0
        if loss_pct >= self.daily_loss_limit:
            log.warning(f"⛔ KILL SWITCH: {loss_pct*100:.1f}% ≥ {self.daily_loss_limit*100:.0f}%")
            return True
        return False

    def can_open_trade(self, open_positions: int, balance: float) -> bool:
        if open_positions >= self.max_pos:
            log.info(f"Max positions ({self.max_pos}) reached.")
            return False
        if self.is_kill_switch(balance):
            return False

        # FIX: en DRY_RUN no bloquear por balance $0
        if not DRY_RUN and balance < MIN_NOTIONAL * 3:
            log.warning(
                f"Balance too low: ${balance:.2f} (min ${MIN_NOTIONAL*3:.0f}). "
                "Verifica API keys y permisos de Futures en BingX."
            )
            return False
        return True

    def size_position(
        self,
        symbol:          str,
        direction:       str,
        entry:           float,
        sl:              float,
        tp1:             float,
        tp2:             float,
        tp3:             float,
        balance:         float,
        qty_precision:   int = 3,
        price_precision: int = 4,
    ) -> Optional[TradeParams]:
        # En DRY_RUN con balance $0, usar balance ficticio para calcular qty
        effective_balance = balance if balance > 0 else (1000.0 if DRY_RUN else 0.0)
        if effective_balance <= 0:
            log.warning(f"Balance $0 en modo LIVE → no se puede calcular posición")
            return None

        risk_usdt = effective_balance * self.risk_pct
        sl_dist   = abs(entry - sl)

        if sl_dist < 1e-10:
            log.warning(f"SL demasiado cerca para {symbol}")
            return None

        qty_raw = risk_usdt / sl_dist
        qty     = round(qty_raw, qty_precision)

        if qty <= 0:
            log.warning(f"Qty=0 para {symbol}")
            return None

        notional = qty * entry
        if notional < MIN_NOTIONAL:
            qty      = round(MIN_NOTIONAL * 1.1 / entry, qty_precision)
            notional = qty * entry

        margin_required = notional / self.leverage
        max_margin      = effective_balance * 0.30

        if margin_required > max_margin:
            log.warning(
                f"{symbol}: margin ${margin_required:.2f} > 30% (${max_margin:.2f}). "
                f"Reduciendo qty."
            )
            qty      = round((max_margin * self.leverage) / entry, qty_precision)
            notional = qty * entry
            if qty <= 0:
                return None

        est_fee = notional * TAKER_FEE * 2   # entrada market + salida market

        log.info(
            f"📐 [{symbol}] {direction} qty={qty} entry={round(entry,price_precision)} "
            f"SL={round(sl,price_precision)} TP1={round(tp1,price_precision)} "
            f"notional=${notional:.1f} risk=${risk_usdt:.2f} margin=${margin_required:.2f}"
        )

        return TradeParams(
            symbol=symbol, direction=direction,
            entry_price=round(entry, price_precision),
            sl_price=round(sl, price_precision),
            tp1_price=round(tp1, price_precision),
            tp2_price=round(tp2, price_precision),
            tp3_price=round(tp3, price_precision),
            quantity=qty, leverage=self.leverage,
            notional=notional, risk_usdt=risk_usdt,
            est_fee=est_fee,
        )

    def get_stats(self) -> dict:
        return {
            "daily_pnl":    round(self._daily_pnl, 4),
            "weekly_pnl":   round(self._weekly_pnl, 4),
            "daily_trades": self._daily_trades,
            "total_fees":   round(self._total_fees, 4),
        }
