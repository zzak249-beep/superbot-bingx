"""
Scanner v4.0 — con Filtros Institucionales
Mejoras sobre v3:
  - Integra InstitutionalFilters (funding, sesión, CVD, liquidez)
  - Pre-filtro por volumen 24h real ($1M+ para mayor liquidez)
  - Timeout por símbolo para no bloquearse
  - Pesos de score por sesión (US session = +10% score bonus)
  - Blacklist de pares problemáticos
  - Top-N por score con filtros institucionales aplicados
"""
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError as FutureTimeout
from dataclasses import dataclass
from typing import Optional
import os

from strategy import compute_signal, Signal
from filters import InstitutionalFilters, quick_validate, SessionStatus

log = logging.getLogger(__name__)

# ── Config ────────────────────────────────────────────────────────────
SCAN_WORKERS    = int(os.environ.get("SCAN_WORKERS", "12"))
SCAN_TIMEOUT    = int(os.environ.get("SCAN_TIMEOUT", "18"))      # seg por símbolo
MIN_VOLUME_USD  = float(os.environ.get("MIN_VOLUME_USD", "1000000"))   # $1M 24h
MIN_SCORE       = float(os.environ.get("MIN_SCORE_SCAN", "45"))       # era 50
KLINE_INTERVAL  = os.environ.get("KLINE_INTERVAL", "5m")
KLINE_LIMIT     = int(os.environ.get("KLINE_LIMIT", "250"))
HTF_INTERVAL    = os.environ.get("HTF_INTERVAL", "1h")
HTF_LIMIT       = int(os.environ.get("HTF_LIMIT", "50"))
MAX_RESULTS     = int(os.environ.get("MAX_SCAN_RESULTS", "8"))

# Pares que históricamente dan señales falsas o tienen liquidez deficiente
BLACKLIST = {
    "LUNA-USDT", "LUNC-USDT", "USTC-USDT",
    "SHIB-USDT",  # precisión muy pequeña → errores de redondeo
}

# Bonus de score por sesión
SESSION_BONUS = {
    SessionStatus.BEST: 10.0,
    SessionStatus.OK:    5.0,
    SessionStatus.AVOID: 0.0,
}


@dataclass
class ScanResult:
    symbol:  str
    signal:  Signal
    score:   float       # score ajustado con filtros institucionales
    filters: list        # razones de los filtros


class Scanner:
    def __init__(self, client):
        self.client  = client
        self.filters = InstitutionalFilters(client)

    def _get_klines(self, symbol: str, interval: str, limit: int) -> list:
        raw = self.client.get_klines(symbol, interval, limit)
        if not raw:
            return []
        candles = []
        for k in raw:
            try:
                if isinstance(k, dict):
                    candles.append({
                        "ts":     float(k.get("time", k.get("t", 0))),
                        "open":   float(k.get("open",  k.get("o", 0))),
                        "high":   float(k.get("high",  k.get("h", 0))),
                        "low":    float(k.get("low",   k.get("l", 0))),
                        "close":  float(k.get("close", k.get("c", 0))),
                        "volume": float(k.get("volume",k.get("v", 0))),
                    })
                elif isinstance(k, list) and len(k) >= 6:
                    candles.append({
                        "ts":     float(k[0]),
                        "open":   float(k[1]),
                        "high":   float(k[2]),
                        "low":    float(k[3]),
                        "close":  float(k[4]),
                        "volume": float(k[5]),
                    })
            except Exception:
                continue
        return candles

    def _get_htf_rsi(self, symbol: str) -> float:
        """RSI en timeframe superior (1h) como contexto macro."""
        try:
            klines = self._get_klines(symbol, HTF_INTERVAL, HTF_LIMIT)
            if len(klines) < 15:
                return 50.0
            import numpy as np
            closes = np.array([k["close"] for k in klines], dtype=float)
            delta  = np.diff(closes, prepend=np.nan)
            gain   = np.where(delta > 0, delta, 0.0)
            loss   = np.where(delta < 0, -delta, 0.0)
            ag     = _ema_np(gain, 14)
            al     = _ema_np(loss, 14)
            rs     = np.where(al == 0, 100.0, ag / al)
            rsi    = 100 - (100 / (1 + rs))
            return float(rsi[-1]) if not np.isnan(rsi[-1]) else 50.0
        except Exception:
            return 50.0

    def _scan_symbol(self, symbol: str) -> Optional[ScanResult]:
        try:
            # Pre-filtro de volumen
            vol24 = self.client.get_24h_volume(symbol)
            if vol24 < MIN_VOLUME_USD:
                return None

            klines = self._get_klines(symbol, KLINE_INTERVAL, KLINE_LIMIT)
            if len(klines) < 50:
                return None

            htf_rsi = self._get_htf_rsi(symbol)
            signal  = compute_signal(klines, htf_rsi)

            if signal.direction == "NONE":
                return None
            if signal.score < MIN_SCORE:
                return None

            # Filtros institucionales
            ok, reason = quick_validate(
                self.filters,
                symbol,
                signal.direction,
                signal.tier,
                signal.entry,
                signal.sl,
                signal.tp1,
                klines,
                signal.atr,
            )
            if not ok:
                log.debug(f"[{symbol}] Filtros institucionales: {reason}")
                return None

            # Bonus de sesión
            session  = InstitutionalFilters.get_session()
            bonus    = SESSION_BONUS.get(session, 0)
            adj_score = min(signal.score + bonus, 100.0)

            # Bonus por volumen (liquidez extra = menos slippage)
            if vol24 > MIN_VOLUME_USD * 5:
                adj_score = min(adj_score + 5, 100.0)

            log.info(
                f"✨ [{symbol}] {signal.direction} [{signal.tier}] "
                f"score={adj_score:.0f} | {signal.reason[:80]}"
            )
            return ScanResult(symbol, signal, adj_score, [reason])

        except Exception as e:
            log.debug(f"Scan error {symbol}: {e}")
            return None

    def scan(self) -> list[ScanResult]:
        """Escanea todos los pares en paralelo y retorna los mejores."""
        start = time.time()
        try:
            symbols = self.client.get_all_symbols()
        except Exception as e:
            log.error(f"Error obteniendo símbolos: {e}")
            return []

        # Filtrar blacklist
        symbols = [s for s in symbols if s not in BLACKLIST]
        log.info(f"🔍 Escaneando {len(symbols)} pares con {SCAN_WORKERS} workers...")

        results = []
        with ThreadPoolExecutor(max_workers=SCAN_WORKERS) as ex:
            futures = {ex.submit(self._scan_symbol, s): s for s in symbols}
            for fut in as_completed(futures, timeout=SCAN_TIMEOUT * 3):
                sym = futures[fut]
                try:
                    res = fut.result(timeout=SCAN_TIMEOUT)
                    if res:
                        results.append(res)
                except FutureTimeout:
                    log.debug(f"Timeout {sym}")
                except Exception as e:
                    log.debug(f"Error {sym}: {e}")

        # Ordenar por score descendente
        results.sort(key=lambda r: r.score, reverse=True)
        elapsed = time.time() - start

        log.info(
            f"📊 Scan completo: {len(results)}/{len(symbols)} señales "
            f"en {elapsed:.1f}s | Sesión: {InstitutionalFilters.get_session()}"
        )
        return results[:MAX_RESULTS]


def _ema_np(series, period):
    """EMA simple para cálculo de HTF RSI."""
    import numpy as np
    out = np.full_like(series, np.nan, dtype=float)
    k   = 2.0 / (period + 1)
    for i in range(len(series)):
        if np.isnan(series[i]):
            continue
        if i == 0 or np.isnan(out[i - 1]):
            out[i] = series[i]
        else:
            out[i] = series[i] * k + out[i - 1] * (1 - k)
    return out
