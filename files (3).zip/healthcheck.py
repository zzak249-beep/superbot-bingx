"""
healthcheck.py — Mini servidor HTTP para Railway healthcheck
Corre en un hilo separado, no interfiere con el bot.
"""
import threading
import logging
from http.server import HTTPServer, BaseHTTPRequestHandler

log = logging.getLogger("Health")

_start_time = None
_bot_status = {"running": False, "cycle": 0}


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ("/", "/health", "/healthz"):
            body = b"OK"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):
        pass  # silenciar logs de requests


def start(port: int = 8080):
    """Inicia el servidor en un hilo daemon (se cierra con el proceso principal)."""
    server = HTTPServer(("0.0.0.0", port), _Handler)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    log.info(f"🩺 Healthcheck server en puerto {port}")
