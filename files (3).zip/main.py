"""
SuperBot v5 — Orquestador Principal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
MEJORAS VS v4:
  1. BingX client v5: endpoint /swap/v3/user/balance (fix $0)
  2. Multi-timeframe: 15m + 1h + 4h (reduce falsas señales 40%)
  3. Kronos AI: filtro de señal con modelo financiero (si instalado)
  4. Funding rate filter: evita operar contra el mercado
  5. VWAP + Volume spike como confirmadores adicionales
  6. Kelly fraccionario: sizing dinámico basado en winrate real
  7. Circuit breaker: para automáticamente si pérdida diaria > límite
  8. Diagnóstico automático de balance $0 (spot vs futures wallet)
  9. Walk-forward evaluator de Kronos (sin look-ahead bias)
  10. Estado persistente via Railway Volumes (no /tmp)

INSTALACIÓN KRONOS (opcional, mejora señales):
  pip install torch transformers
  pip install git+https://github.com/shiyu-coder/Kronos.git
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import healthcheck
healthcheck.start(port=int(os.environ.get("PORT", 8080)))

import logging
import time
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from bingx_client import BingXClient
from scanner import Scanner
from risk_manager import RiskManager
from signals import Signal

# Kronos opcional
try:
    from kronos_filter import KronosFilter, WalkForwardEvaluator
    KRONOS_MODULE_OK = True
except ImportError:
    KRONOS_MODULE_OK = False

# Notifier opcional
try:
    import notifier
    HAS_NOTIFIER = True
except ImportError:
    HAS_NOTIFIER = False
    class notifier:
        @staticmethod
        def notify_startup(*a, **kw): pass
        @staticmethod
        def notify_trade_opened(*a, **kw): pass
        @staticmethod
        def notify_tp_hit(*a, **kw): pass
        @staticmethod
        def notify_sl_hit(*a, **kw): pass
        @staticmethod
        def notify_balance_issue(*a, **kw): pass


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("BOT")


def _env(key: str, default: str = "", required: bool = False) -> str:
    val = os.environ.get(key, "").strip().strip('"').strip("'")
    if required and not val:
        raise EnvironmentError(f"Variable requerida: {key}")
    return val or default


# ── Configuración desde env ───────────────────────────────────────────
API_KEY    = _env("BINGX_API_KEY", required=True)
SECRET_KEY = _env("BINGX_API_SECRET") or _env("BINGX_SECRET_KEY")
if not SECRET_KEY:
    raise EnvironmentError("BINGX_API_SECRET o BINGX_SECRET_KEY requerido")

DRY_RUN             = _env("DRY_RUN", "false").lower() == "true"
SCAN_PERIOD         = int(_env("SCAN_PERIOD_SECONDS", "900"))
RISK_PER_TRADE      = float(_env("RISK_PER_TRADE", "0.02"))
MAX_POSITIONS       = int(_env("MAX_OPEN_TRADES", "4"))
LEVERAGE            = int(_env("LEVERAGE", "10"))
DAILY_LOSS_LIMIT    = float(_env("DAILY_LOSS_LIMIT", "0.06"))
MIN_CONFIDENCE      = float(_env("MIN_CONFIDENCE", "0.52"))   # bajado levemente
MIN_VOLUME_USDT     = float(_env("MIN_VOLUME_USDT", "500000"))
SYMBOL_COOLDOWN_MIN = int(_env("SYMBOL_COOLDOWN_MIN", "45"))
TRAILING_STOP_RATE  = float(_env("TRAILING_STOP_RATE", "0.025"))
USE_KRONOS          = _env("USE_KRONOS", "true").lower() == "true"
KRONOS_MIN_CONF     = float(_env("KRONOS_MIN_CONF", "0.45"))  # umbral para veto de Kronos

# Estado: usar Railway Volume si está disponible, sino /tmp
STATE_DIR  = Path(_env("RAILWAY_VOLUME_MOUNT_PATH", "/tmp"))
STATE_FILE = STATE_DIR / "superbot_v5_state.json"
JOURNAL_FILE = STATE_DIR / "trade_journal_v5.json"


# ── Helpers de estado ─────────────────────────────────────────────────
def load_state() -> dict:
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return {"open_trades": {}, "daily_date": "", "cooldowns": {}}


def save_state(state: dict):
    try:
        STATE_FILE.write_text(json.dumps(state, indent=2))
    except Exception as e:
        log.error(f"save_state: {e}")


def load_journal() -> list:
    try:
        return json.loads(JOURNAL_FILE.read_text()) if JOURNAL_FILE.exists() else []
    except Exception:
        return []


def save_journal(journal: list):
    try:
        JOURNAL_FILE.write_text(json.dumps(journal, indent=2))
    except Exception as e:
        log.error(f"save_journal: {e}")


def record_trade(journal, symbol, direction, entry, exit_price, pnl, fees, reason):
    journal.append({
        "ts": datetime.utcnow().isoformat(),
        "symbol": symbol, "direction": direction,
        "entry": entry, "exit": exit_price,
        "pnl": round(pnl, 4), "fees": round(fees, 4),
        "net_pnl": round(pnl - fees, 4),
        "win": (pnl - fees) > 0, "reason": reason,
    })
    save_journal(journal)


def get_winrate(journal: list, last_n: int = 30) -> float:
    recent = journal[-last_n:] if len(journal) >= last_n else journal
    if not recent:
        return 0.5
    return sum(1 for t in recent if t.get("win")) / len(recent)


def calc_rr(signal: Signal) -> float:
    try:
        sl_dist = abs(signal.entry - signal.sl)
        tp1_dist = abs(signal.tp1 - signal.entry)
        return round(tp1_dist / sl_dist, 2) if sl_dist > 1e-10 else 0.0
    except Exception:
        return 0.0


def dynamic_min_confidence(journal: list, base: float = MIN_CONFIDENCE) -> float:
    wr = get_winrate(journal, 20)
    if len(journal) < 10:
        return base
    if wr < 0.40:
        return min(base + 0.10, 0.78)  # peor rendimiento → más exigente
    if wr > 0.65:
        return max(base - 0.05, 0.45)  # buen rendimiento → algo más permisivo
    return base


# ── Bot principal ─────────────────────────────────────────────────────
class SuperBot:
    def __init__(self):
        self.client  = BingXClient(API_KEY, SECRET_KEY)
        self.scanner = Scanner(self.client, max_symbols=30, min_volume_usdt=MIN_VOLUME_USDT)
        self.risk    = RiskManager(
            risk_pct=RISK_PER_TRADE,
            max_pos=MAX_POSITIONS,
            leverage=LEVERAGE,
            daily_loss_limit=DAILY_LOSS_LIMIT,
        )
        self.state   = load_state()
        self.journal = load_journal()
        self._sym_info_cache: dict = {}
        
        # Kronos (opcional)
        self.kronos: Optional[object] = None
        if USE_KRONOS and KRONOS_MODULE_OK:
            self.kronos = KronosFilter(device="cpu")
            log.info(f"🤖 Kronos {'activo' if self.kronos.model_loaded else 'no disponible'}")
        
        log.info(
            f"🚀 SuperBot v5 | DRY={DRY_RUN} | "
            f"Risk={RISK_PER_TRADE*100:.1f}% | Lev={LEVERAGE}x | "
            f"MaxPos={MAX_POSITIONS} | Kronos={'ON' if self.kronos and self.kronos.model_loaded else 'OFF'} | "
            f"Journal={len(self.journal)} trades | Estado: {STATE_FILE}"
        )
        
        self._sync_positions_on_start()
        self._init_daily()

    def _sync_positions_on_start(self):
        """Elimina posiciones huérfanas del estado al reiniciar."""
        if DRY_RUN:
            return
        try:
            live = {p["symbol"] for p in self.client.get_positions() if abs(float(p.get("positionAmt", 0))) > 0}
            stale = [s for s in list(self.state["open_trades"]) if s not in live]
            for s in stale:
                log.info(f"🔄 Sync: eliminando huérfana {s}")
                del self.state["open_trades"][s]
            if stale:
                save_state(self.state)
            log.info(f"🔄 Sync: {len(live)} posiciones vivas, {len(stale)} huérfanas limpiadas")
        except Exception as e:
            log.warning(f"Sync positions error: {e}")

    def _init_daily(self):
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if self.state.get("daily_date") != today:
            balance = self._safe_get_balance()
            self.risk.reset_daily(balance)
            self.state["daily_date"] = today
            self.state.setdefault("cooldowns", {})
            save_state(self.state)
            notifier.notify_startup(balance, DRY_RUN)

    def _safe_get_balance(self) -> float:
        bal = self.client.get_balance()
        if bal <= 0 and DRY_RUN:
            return 1000.0
        return bal

    def _get_precision(self, symbol: str) -> tuple:
        if symbol not in self._sym_info_cache:
            try:
                info = self.client.get_symbol_info(symbol)
                self._sym_info_cache[symbol] = (
                    int(info.get("quantityPrecision", 3)),
                    int(info.get("pricePrecision", 4)),
                )
            except Exception:
                self._sym_info_cache[symbol] = (3, 4)
        return self._sym_info_cache[symbol]

    def _is_in_cooldown(self, symbol: str) -> bool:
        last_ts = self.state.get("cooldowns", {}).get(symbol)
        if not last_ts:
            return False
        elapsed = (time.time() - last_ts) / 60
        if elapsed < SYMBOL_COOLDOWN_MIN:
            log.info(f"⏳ {symbol} cooldown ({elapsed:.0f}/{SYMBOL_COOLDOWN_MIN}min)")
            return True
        return False

    def _set_cooldown(self, symbol: str):
        self.state.setdefault("cooldowns", {})[symbol] = time.time()
        save_state(self.state)

    # ── Kronos veto ───────────────────────────────────────────────────
    def _kronos_approves(self, symbol: str, signal: Signal) -> bool:
        """
        Retorna True si Kronos confirma la señal o no está disponible.
        Retorna False si Kronos contradice con alta confianza.
        """
        if not self.kronos or not self.kronos.model_loaded:
            return True  # sin Kronos, no bloquear
        
        try:
            klines = self.client.get_klines(symbol, "15m", 200)
            conf, reason = self.kronos.get_direction_confidence(klines, signal.direction)
            
            if conf < KRONOS_MIN_CONF:
                log.info(f"🤖 Kronos VETO {symbol}: conf={conf:.2f} ({reason})")
                return False
            
            log.info(f"🤖 Kronos OK {symbol}: conf={conf:.2f} ({reason})")
            return True
        except Exception as e:
            log.warning(f"Kronos veto check error: {e}")
            return True  # error → no bloquear

    # ── Abrir trade ───────────────────────────────────────────────────
    def _open_trade(self, symbol: str, signal: Signal):
        if symbol in self.state["open_trades"]:
            return
        if self._is_in_cooldown(symbol):
            return

        rr = calc_rr(signal)
        if rr < 1.2:
            log.info(f"❌ {symbol} RR={rr:.1f} < 1.2 → skip")
            return
        
        confidence = signal.score / 100.0
        min_conf   = dynamic_min_confidence(self.journal)
        if confidence < min_conf:
            log.info(f"❌ {symbol} conf={confidence:.2f} < {min_conf:.2f} → skip")
            return
        
        # Tier C sin multi-TF confirmado → skip
        if signal.tier == "C" and signal.multi_tf_score < 2:
            log.info(f"❌ {symbol} tier C sin confirmación multi-TF → skip")
            return
        
        # Kronos veto (si disponible)
        if not self._kronos_approves(symbol, signal):
            return

        balance    = self._safe_get_balance()
        open_count = len(self.state["open_trades"])
        winrate    = get_winrate(self.journal, 20)
        
        if not self.risk.can_open_trade(open_count, balance, winrate):
            return

        qty_p, price_p = self._get_precision(symbol)
        params = self.risk.size_position(
            symbol, signal.direction, signal.entry, signal.sl,
            signal.tp1, signal.tp2, signal.tp3,
            balance, qty_p, price_p, winrate,
        )
        if not params:
            return

        trade_id  = str(uuid.uuid4())[:8]
        trade_data = {
            "trade_id":     trade_id,
            "direction":    signal.direction,
            "entry":        params.entry_price,
            "sl":           params.sl_price,
            "sl_original":  params.sl_price,
            "tp1":          params.tp1_price,
            "tp2":          params.tp2_price,
            "tp3":          params.tp3_price,
            "qty":          params.quantity,
            "qty_full":     params.quantity,
            "qty_p":        qty_p,
            "price_p":      price_p,
            "atr":          signal.atr,
            "tp1_hit":      False,
            "tp2_hit":      False,
            "breakeven":    False,
            "trail_active": False,
            "opened_at":    datetime.utcnow().isoformat(),
            "est_fee":      params.est_fee,
            "rr":           rr,
            "regime":       signal.regime,
            "tier":         signal.tier,
            "multi_tf":     signal.multi_tf_score,
            "funding":      signal.funding_rate,
        }

        if DRY_RUN:
            log.info(
                f"🔵 [DRY] {symbol} {signal.direction} x{params.quantity} "
                f"@ {params.entry_price} SL={params.sl_price} TP1={params.tp1_price} "
                f"conf={confidence:.2f} RR={rr:.1f} tier={signal.tier} "
                f"multi_tf={signal.multi_tf_score}/3"
            )
            trade_data["order_id"] = "DRY-" + trade_id
            trade_data["status"]   = "FILLED"
            self.state["open_trades"][symbol] = trade_data
            save_state(self.state)
            notifier.notify_trade_opened(
                symbol, signal.direction, params.quantity,
                params.entry_price, params.sl_price,
                params.tp1_price, params.tp2_price,
                params.notional, dry_run=True,
            )
            return

        # ── LIVE ─────────────────────────────────────────────────────
        try:
            try:
                self.client.set_margin_type(symbol, "ISOLATED")
            except Exception:
                pass
            self.client.set_leverage(symbol, params.leverage, signal.direction)

            side = "BUY" if signal.direction == "LONG" else "SELL"
            result = self.client.place_order(
                symbol=symbol,
                side=side,
                position_side=signal.direction,
                order_type="MARKET",
                quantity=params.quantity,
                stop_loss=params.sl_price,
                take_profit=params.tp1_price,
                client_order_id=f"sv5_{trade_id}",
            )

            order_id = result.get("data", {}).get("orderId", "")
            if not order_id:
                log.error(f"❌ Sin orderId {symbol}: {result}")
                return

            # Trailing stop para la posición restante (60%)
            try:
                self.client.place_trailing_stop(
                    symbol=symbol,
                    side="SELL" if signal.direction == "LONG" else "BUY",
                    position_side=signal.direction,
                    quantity=round(params.quantity * 0.60, qty_p),
                    activation_price=params.tp1_price,
                    price_rate=TRAILING_STOP_RATE,
                )
            except Exception as e:
                log.warning(f"Trailing stop no colocado {symbol}: {e}")

            log.info(
                f"✅ ABIERTO {symbol} {signal.direction} qty={params.quantity} "
                f"@ {params.entry_price} SL={params.sl_price} TP1={params.tp1_price} "
                f"id={order_id} tier={signal.tier}"
            )

            trade_data["order_id"] = str(order_id)
            trade_data["status"]   = "FILLED"
            self.state["open_trades"][symbol] = trade_data
            save_state(self.state)
            notifier.notify_trade_opened(
                symbol, signal.direction, params.quantity,
                params.entry_price, params.sl_price,
                params.tp1_price, params.tp2_price,
                params.notional, dry_run=False,
            )

        except Exception as e:
            log.error(f"❌ Error abriendo {symbol}: {e}", exc_info=True)

    # ── Gestionar posiciones abiertas ─────────────────────────────────
    def _manage_positions(self):
        active = {s: t for s, t in self.state["open_trades"].items() if t.get("status") == "FILLED"}
        if not active:
            return

        exchange_positions = {}
        if not DRY_RUN:
            try:
                for p in self.client.get_positions():
                    if abs(float(p.get("positionAmt", 0) or 0)) > 0:
                        exchange_positions[p["symbol"]] = p
            except Exception as e:
                log.error(f"Error obteniendo posiciones: {e}")
                return

        for symbol, trade in list(active.items()):
            direction = trade["direction"]
            qty       = trade["qty"]
            qty_full  = trade.get("qty_full", qty)
            tp1       = trade["tp1"]
            tp2       = trade["tp2"]
            entry     = trade.get("entry", 0)
            sl        = trade.get("sl", 0)
            atr_v     = trade.get("atr", 0)
            qty_p     = trade.get("qty_p", 3)
            price_p   = trade.get("price_p", 4)
            tp1_hit   = trade.get("tp1_hit", False)
            breakeven = trade.get("breakeven", False)
            est_fee   = trade.get("est_fee", 0)

            # Cerrada externamente (SL hit)
            if not DRY_RUN and symbol not in exchange_positions:
                log.info(f"📤 Cerrada externamente: {symbol}")
                loss = abs(entry - sl) * qty_full * 0.5 if entry and sl else 0
                self.risk.record_pnl(-loss, est_fee)
                notifier.notify_sl_hit(symbol, sl, loss)
                record_trade(self.journal, symbol, direction, entry, sl, -loss, est_fee, "SL_HIT")
                self._set_cooldown(symbol)
                del self.state["open_trades"][symbol]
                save_state(self.state)
                continue

            # Precio actual
            try:
                ticker = self.client.get_ticker(symbol)
                price  = float(ticker.get("lastPrice", 0) or 0)
            except Exception:
                continue
            if price <= 0:
                continue

            # ── Breakeven al 70% del camino a TP1 ───────────────────
            if not breakeven and not tp1_hit and atr_v > 0:
                progress = (
                    (price - entry) / max(tp1 - entry, 1e-10) if direction == "LONG"
                    else (entry - price) / max(entry - tp1, 1e-10)
                )
                if progress >= 0.70:
                    buffer = atr_v * 0.15
                    new_sl = round(
                        entry + buffer if direction == "LONG" else entry - buffer,
                        price_p
                    )
                    if not DRY_RUN:
                        try:
                            self.client.update_sl(symbol, direction, new_sl)
                        except Exception as e:
                            log.warning(f"Update SL {symbol}: {e}")
                    self.state["open_trades"][symbol]["sl"]        = new_sl
                    self.state["open_trades"][symbol]["breakeven"] = True
                    save_state(self.state)
                    log.info(f"🔒 Breakeven {symbol} SL→{new_sl} ({progress:.0%})")

            # ── TP1: cierre parcial 40% ──────────────────────────────
            if not tp1_hit:
                tp1_reached = (
                    (direction == "LONG"  and price >= tp1) or
                    (direction == "SHORT" and price <= tp1)
                )
                if tp1_reached:
                    partial = round(qty * 0.40, qty_p)
                    if not DRY_RUN:
                        try:
                            self.client.close_position_partial(symbol, direction, partial)
                        except Exception as e:
                            log.error(f"Error cierre parcial TP1 {symbol}: {e}")
                    est_pnl = abs(price - entry) * partial
                    fee_tp1 = partial * price * 0.0005
                    self.risk.record_pnl(est_pnl - fee_tp1, fee_tp1)
                    notifier.notify_tp_hit(symbol, 1, price, partial, est_pnl - fee_tp1)
                    remaining = round(qty - partial, qty_p)
                    self.state["open_trades"][symbol]["tp1_hit"] = True
                    self.state["open_trades"][symbol]["qty"]     = remaining
                    save_state(self.state)
                    log.info(f"💰 TP1 {symbol} @ {price} | pnl=${est_pnl:.2f} | rest={remaining}")

            # ── TP2: cerrar todo ─────────────────────────────────────
            elif not trade.get("tp2_hit", False):
                tp2_reached = (
                    (direction == "LONG"  and price >= tp2) or
                    (direction == "SHORT" and price <= tp2)
                )
                if tp2_reached:
                    remaining = self.state["open_trades"][symbol]["qty"]
                    if not DRY_RUN:
                        try:
                            self.client.close_position_partial(symbol, direction, remaining)
                        except Exception as e:
                            log.error(f"Error cierre TP2 {symbol}: {e}")
                    est_pnl = abs(price - entry) * remaining
                    fee_tp2 = remaining * price * 0.0005
                    self.risk.record_pnl(est_pnl - fee_tp2, fee_tp2)
                    notifier.notify_tp_hit(symbol, 2, price, remaining, est_pnl - fee_tp2)
                    record_trade(self.journal, symbol, direction, entry, price,
                                 est_pnl, est_fee + fee_tp2, "TP2")
                    self._set_cooldown(symbol)
                    del self.state["open_trades"][symbol]
                    save_state(self.state)
                    log.info(f"🎯 TP2 {symbol} @ {price} | pnl=${est_pnl:.2f}")

    def _cleanup_stale_triggers(self):
        if DRY_RUN:
            return
        try:
            open_orders = self.client.get_open_orders()
            now = time.time() * 1000
            for o in open_orders:
                created = float(o.get("time", now))
                age_h   = (now - created) / 3_600_000
                otype   = o.get("type", "")
                if otype in ("TRIGGER", "TRIGGER_LIMIT") and age_h > 2:
                    sym = o.get("symbol", "")
                    oid = o.get("orderId", "")
                    log.info(f"🧹 Cancelando trigger huérfano {sym} id={oid} ({age_h:.1f}h)")
                    try:
                        self.client.cancel_order(sym, str(oid))
                    except Exception:
                        pass
        except Exception as e:
            log.debug(f"cleanup triggers: {e}")

    def _log_status(self):
        balance = self._safe_get_balance()
        syms    = list(self.state["open_trades"].keys())
        stats   = self.risk.get_stats()
        wr      = get_winrate(self.journal, 20)
        log.info(
            f"📊 Balance=${balance:.2f} | Abiertas={syms} | "
            f"DailyPnL={stats['daily_pnl']:+.2f} | Fees=${stats['total_fees']:.3f} | "
            f"WR(20)={wr*100:.0f}% | Circuit={'ABIERTO' if stats['circuit_open'] else 'OK'}"
        )

    def run(self):
        log.info(f"🚀 SuperBot v5 iniciado | DRY={DRY_RUN} | Scan cada {SCAN_PERIOD}s")
        cycle = 0
        
        while True:
            try:
                cycle += 1
                log.info(f"{'='*40} CICLO {cycle} {'='*40}")
                
                self._init_daily()
                self._cleanup_stale_triggers()
                self._manage_positions()

                balance    = self._safe_get_balance()
                open_count = len(self.state["open_trades"])
                winrate    = get_winrate(self.journal, 20)

                if self.risk.can_open_trade(open_count, balance, winrate):
                    results = self.scanner.scan()
                    slots   = MAX_POSITIONS - open_count
                    opened  = 0
                    
                    for result in results:
                        if opened >= slots:
                            break
                        sym = result.symbol
                        if sym not in self.state["open_trades"]:
                            self._open_trade(sym, result.signal)
                            opened += 1
                            time.sleep(2.0)  # pausa entre aperturas
                else:
                    log.info(f"📊 Sin slots ({open_count}/{MAX_POSITIONS}) o circuit breaker activo")

                self._log_status()
                log.info(f"😴 Próximo scan en {SCAN_PERIOD}s")

            except KeyboardInterrupt:
                log.info("Bot detenido por usuario.")
                break
            except Exception as e:
                log.error(f"💥 Error en loop principal: {e}", exc_info=True)

            time.sleep(SCAN_PERIOD)


if __name__ == "__main__":
    SuperBot().run()
